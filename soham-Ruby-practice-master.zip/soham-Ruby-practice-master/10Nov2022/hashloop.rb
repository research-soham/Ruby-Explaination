color = {   
    "color1" => "red",   
    "color2" => "purple",   
    "color3" => "yellow",   
    "color4" => "white"   
  }   
  color['color5'] = "pink"   
  color.each do |key, value|   
  puts "#{key} value is #{value}"   
 end  













 