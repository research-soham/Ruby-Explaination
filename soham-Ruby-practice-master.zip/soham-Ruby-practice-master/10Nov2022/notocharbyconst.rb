# To Take no from user and convert into char
print "Enter First Number"
n1=gets.chop.to_i

class My_number 
    def initialize(num1)
        puts num1.chr
    end
    
end

obj =My_number.new(n1)
