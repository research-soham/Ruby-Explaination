
data={1=>"vishal",2=>"himanshu",3=>"soham",4=>"kapil"}

puts data[1]
puts data[2]
puts data[3]
puts data[4]
#p data.keys
#p data

p data.keys	
#p data.default(key = nil)
#p data

#To set obj
#data.default=obj 
#p data

# To clear the complete hash
#p data.clear


