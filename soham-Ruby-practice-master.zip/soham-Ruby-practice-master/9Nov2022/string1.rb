
#string="this our city we need to keep clean to is it"
#str2="this"

# it will search str2 in given string from Right/Ending side of String
#p string.rindex(str2)

# It will check String is starting from str2 or not
# p string.start_with?(str2)

string1=" soham "
string2="baghela"
# To add Two String
#p string1+string2
# To add Two String
#p string1<<string2
# To Change/replace string/character from a particular Index
# string1[1]="h"
# p string1

#p string1[5,12]=string2

# string1["a"]="*"
#p string1

# It took last character of string and put next character of that
# p string1.succ

# It put string2 in starting of string1 
#p string1.prepend(string2)












