print "Enter Any String"
mystring=gets

check=mystring.start_with?("if")

print check

