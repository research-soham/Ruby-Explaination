print "Enter Any String"
mystring=gets.chop
arr1= mystring.split(' ').reverse.join(' ')
p arr1

