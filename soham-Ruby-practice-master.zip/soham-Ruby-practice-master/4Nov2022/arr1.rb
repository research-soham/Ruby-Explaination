a=[]
for i in 1..5 do
    p Array.new(i,'a')
end
