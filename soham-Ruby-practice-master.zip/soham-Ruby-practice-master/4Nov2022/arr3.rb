print "enter Radius of Circle"
r=gets.chop.to_f
pi=3.14
parimeter=2*pi*r

print "Parimeter : #{parimeter} " 
p ''





