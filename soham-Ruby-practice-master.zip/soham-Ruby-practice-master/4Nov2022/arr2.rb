print "enter Radius of Circle"
r=gets.chop.to_f
pi=3.14
area=pi*r*r 
print "Area of Circle : #{ area}" 
p ''



