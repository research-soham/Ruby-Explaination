    # a= 255
# p a.to_s

#It Convert Float-Up to Integer
# a=255.76
# p a.ceil

#It Convert Float-Down to Integer
# a=255.76
# p a.floor

#It next to Integer
# a=224
# p a.next

#It previous to Integer
# a=224
# p a.pred

#It find Grestest Common Denominator  gcd 
# a=225
# p a.gcd(13)

#It iterate any task to particular Integer Time
# a=4
# a.times do |i|
#     p i
# end

# a=['name','soham','surname','baghela']
# p a.split("")

#To print and store Ascii Value 
# a=''
# for i in 65..90
#     print i.chr
#     if i.chr=="S" || i.chr=="O" && i.chr=="S"
#         a+= i.chr
#     end
# end
# puts 
# for i in 97..122
#     print i.chr
# end
# puts
# puts a;

# a=[10,20,32,43,23,53,35,"nil"]
# b= a.nil?
# p b

# To Create Symbol
 a='a'
 
















































