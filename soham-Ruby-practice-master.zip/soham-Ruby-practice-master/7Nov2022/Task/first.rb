# Q1) Take input n from user, Print series till nth term or zero element.
# 42,40, 38, 35, 33, 31, 28 

# n=42
# print "Enter Your Number to Get Element"
# element=gets.chop.to_i

# for i in (42..0) do
#     print i
# end

n=8
first=-1
second=1

while  n>0 do ||
    p n 
    n+=1
end














# for i in 0..n do
#     p third=first+second;
#     first=second
#     second=third
# end 

# for i in (10).downto(0) do 
#     p i
# end