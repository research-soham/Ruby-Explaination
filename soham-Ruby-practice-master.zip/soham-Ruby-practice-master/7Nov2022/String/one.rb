
mystring="yourname"

p mystring.slice(0..mystring.size)








