#To get length of any String
# a="hello"
# p a.size

#To check String is Empty on Not
# b=""
# p b.empty?

string = "abc123"

# p string[0...3]
# # "abc"

# p string[3,3]
# # "123"

#It genrally checks The given String is Available in it or not
# it is Case Sensitive  
# string = "Today is Saturday"
# p string.include?("Saturday")
# true

# It genrally get the Index from it Starting 
#  string = "Today is Sunday"
#  p string.index("day")
# 2




