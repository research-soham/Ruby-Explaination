#Insert Method can Insert element in any position

arr = %w(cat dog hourse mouse)
# p arr
# arr.insert(1, "cow")
# p arr

# p arr
# arr<<"cow"
# p arr

# p arr
# arr.push("hourse")
# arr.unshift("cow")
# arr.delete("cat") 
# p arr

#p arr
#arr.delete("hourse")
#arr.("cow")
#arr.delete("cat") 
#p arr

# map Method
# arr = %w(a b c)
# arr.map do |value|
#     print value
# end
# puts ''

# Map method with index
# arr = %w(a b c)
# arr.map.with_index do |value, idx|
#   p "index #{idx} is '#{value}'"
# end































