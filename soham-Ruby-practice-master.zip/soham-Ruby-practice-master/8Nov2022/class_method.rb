class Myclass_method 
    def self.concate_string 
        print "enter first string "
        @@first=gets.chop
    end
end