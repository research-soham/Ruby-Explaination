#To get character at given Index 
#a="Career"
#p a.slice(0..2)

# a="Career"
# p "start with 0 and ends with #{a.length-1}"

# To Change the case of Character in given String
# a="yourName"
# p a.upcase
# puts a.downcase
# puts a.swapcase
# puts a.capitalize

# To find the string/ character in the given String
#a="This is a String of data management"
#puts a.include?("of")
#To get index of existing character/string starts with 
#puts a.index("of")

# To check Availablity in given string 
# a="this is my name"
# p a.include?("my")

# To check String is Starts with it or Not
#name = "John Appleseed"
#p name.start_with?("John")

# To check String is Ends with it or Not
#name = "John Appleseed"
#p name.end_with?("d")

# string ="my language is React "
# p string.sub("React","Ruby")

# string1 ="my language is React and i will continue in React"
# p string1.sub("React","Ruby")

# string1 ="my language is React and i will continue in React"
# p string1.gsub!("React","Ruby")
 
# To center your sting/name from begining and end
# name="Soham"
# p name.center(11)

# name="Soham"
# p name.center(11,"*")

#To use ljust 
name = "soham"
p name.rjust(20,"*")





















